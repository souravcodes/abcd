package com.fse.s1.projectmanager.service;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fse.s1.projectmanager.entity.ProjectEntity;
import com.fse.s1.projectmanager.repo.ProjectRepository;
import com.fse.s1.projectmanager.to.ProjectTO;
import com.fse.s1.projectmanager.util.Util;

@Service
public class ProjectService implements IProjectService{

	@Autowired
	private ProjectRepository repo;
	
	@Override
	public List<ProjectTO> getAllProjects() {
		List<ProjectTO> projects = new LinkedList<>();
		repo.findAll().forEach(e -> {
			ProjectTO project = Util.exchangeUserAndUserTo(e, new ProjectTO());
			projects.add(project);
		});
		return projects;
	}

	@Override
	public ProjectTO addProject(ProjectTO projectTo) {
		ProjectEntity project = Util.exchangeUserAndUserTo(projectTo, new ProjectEntity());
		project = this.repo.save(project);
		return Util.exchangeUserAndUserTo(project, projectTo);
	}

	@Override
	public ProjectTO updateProject(ProjectTO projectTo) {
		boolean exists = this.repo.existsById(projectTo.getProjectId());
		ProjectEntity project = new ProjectEntity();
		if(exists){
			this.repo.save(Util.exchangeUserAndUserTo(projectTo, project));
		}
		return Util.exchangeUserAndUserTo(project, projectTo);
	}

	@Override
	public String deleteProjects(long projectId) {
		boolean exists = this.repo.existsById(projectId);
		if(exists){
			this.repo.deleteById(projectId);
			return "success";
		}
		return "missing";
	}

}
