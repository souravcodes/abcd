package com.fse.s1.projectmanager.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fse.s1.projectmanager.entity.ParentTaskEntity;
import com.fse.s1.projectmanager.repo.ParentTaskRepository;

@Service
public class ParentTaskService implements IParentTaskService{

	@Autowired
	private ParentTaskRepository parentTaskRepository;
	
	
	@Override
	public ParentTaskEntity getParentTask(long id){
		return parentTaskRepository.findById(id).orElse(new ParentTaskEntity());
	}

	@Override
	public ParentTaskEntity parentTaskExists(String pt){
		return parentTaskRepository.findByParentTask(pt);
	}

	@Override
	public ParentTaskEntity addParentTask(ParentTaskEntity parentTask){
		return parentTaskRepository.save(parentTask);
	}
	
	@Override
	public ParentTaskEntity getParentByName(String name){
		return parentTaskRepository.findByParentTask(name);
	}
}
