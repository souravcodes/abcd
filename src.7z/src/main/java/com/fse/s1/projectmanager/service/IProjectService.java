package com.fse.s1.projectmanager.service;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fse.s1.projectmanager.to.ProjectTO;

public interface IProjectService {

	public List<ProjectTO> getAllProjects();
	
	public ProjectTO addProject(ProjectTO project);
	
	public ProjectTO updateProject(ProjectTO project);
	
	public String deleteProjects(long projectId);
}
