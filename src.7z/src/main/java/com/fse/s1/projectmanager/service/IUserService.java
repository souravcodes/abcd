package com.fse.s1.projectmanager.service;

import java.util.List;

import com.fse.s1.projectmanager.entity.UserEntity;

public interface IUserService {

	public UserEntity addUser(UserEntity UserEntity);
	public List<UserEntity> getAllUser();
	public UserEntity updateUser(UserEntity UserEntity);
	public String deleteUser(long id);
}
