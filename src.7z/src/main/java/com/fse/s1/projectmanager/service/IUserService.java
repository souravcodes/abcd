package com.fse.s1.projectmanager.service;

import java.util.List;

import com.fse.s1.projectmanager.to.UserTO;

public interface IUserService {

	public UserTO addUser(UserTO userTo);
	public List<UserTO> getAllUser();
	public UserTO updateUser(UserTO userTo);
	public String deleteUser(long id);
}
