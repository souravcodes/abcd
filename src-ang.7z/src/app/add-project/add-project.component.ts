import { Component, OnInit } from '@angular/core';
import { Project } from 'src/app/add-project/project.model';
import { ProjectService } from 'src/app/service/project.service';

@Component({
  selector: 'app-add-project',
  templateUrl: './add-project.component.html',
  styleUrls: ['./add-project.component.css']
})
export class AddProjectComponent implements OnInit {

  projects:Project[] = [];
  addUpdateButtonName:string ="add";
  projectId:string = "";
  project:string = "";
  setdates:boolean = false;
  startDate:string = "";
  endDate:string = "";
  manager:string = "";
  priority:number = 1;

  constructor(private projectService:ProjectService) { }

  ngOnInit() {
    
  }
  display="none";
  openModal(){
      this.display="block"; 
  }

  onCloseHandled(){
      this.display="none"; 
  }
  receiveUpdate(data:Project){
    console.log(data.projectId);
    this.projectId = data.projectId;
    this.project = data.project;
    this.startDate = data.startDate;
    this.endDate = data.endDate;
    this.priority = data.priority;
    this.manager = data.manager;
    this.addUpdateButtonName = "update";
  }

  addProject(){
    if(this.projectId == ""){
      let newProject:Project = new Project("", this.project, this.startDate, this.endDate, this.priority,"","WIP");
      this.projectService.addProject(newProject).subscribe(data => {
        let projectList:Project[] = this.projectService.getProjectList();
        if(projectList == undefined || projectList == [] || projectList == null){
          this.projectService.setProjectList([newProject]);
        }else{
          this.projectService.getProjectList().push(newProject);
        }
        this.projects = this.projectService.getProjectList();
        alert("Project added successfully");
      });
    }else{
      let newProject:Project = new Project(this.projectId, this.project, this.startDate, this.endDate, this.priority,"","WIP");
      this.projectService.updateProject(newProject).subscribe(data => {
         this.projectService.getAllProjects().subscribe(e => {
            this.projects = e;
         });
        alert("data update successful.");
        this.reset();
      });
    }
  }

  reset(){
    this.projectId = "";
    this.project = "";
    this.setdates = false;
    this.startDate = "";
    this.endDate = "";
    this.manager = "";
    this.priority = 1;
    this.addUpdateButtonName = "add";
  }
}
