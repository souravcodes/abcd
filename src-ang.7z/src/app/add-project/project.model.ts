export class Project {
    projectId:string;
	project:string;
	startDate:string;
	endDate:string;
	priority:number;
	manager:string;
    status:string;

    constructor(projectId:string,
                project:string,
                startDate:string,
                endDate:string,
                priority:number,
                manager:string,
                status:string){
        this.projectId = projectId;
        this.project = project;
        this.startDate = startDate;
        this.endDate = endDate;
        this.priority = priority;
        this.manager = manager;
        this.status = status;
    }
}