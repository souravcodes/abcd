export class ParentTask {

    constructor(public parentId:string, public parentTask:string){}
}